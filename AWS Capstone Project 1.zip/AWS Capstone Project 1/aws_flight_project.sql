use flight_db;

-- Average price of all the airlines by class
select airline, class, round(avg(price),2)
as average_price
from flight_db.flight_data_analytics
group by airline, class
order by class, average_price desc;

-- Top five most expensive route's average price
SELECT 
    source_city,
    destination_city,
    ROUND(AVG(price), 2) AS avg_route_price
FROM flight_db.flight_data_analytics
GROUP BY source_city, destination_city
ORDER BY avg_route_price DESC
LIMIT 5;

-- Top five most frequent routes
SELECT 
    source_city,
    destination_city,
    COUNT(*) AS total_flights
FROM flight_db.flight_data_analytics
GROUP BY source_city, destination_city
ORDER BY total_flights DESC
LIMIT 5;

-- Count of flights by airlines
select airline, count(*) as total_flight
from flight_db.flight_data_analytics
group by airline
order by total_flight
desc;

-- Most common arrival time
SELECT arrival_time, COUNT(*) AS total
FROM flight_db.flight_data_analytics
GROUP BY arrival_time
ORDER BY total DESC;

-- Most common deprature time
SELECT departure_time, COUNT(*) AS total
FROM flight_db.flight_data_analytics
GROUP BY departure_time
ORDER BY total DESC;

